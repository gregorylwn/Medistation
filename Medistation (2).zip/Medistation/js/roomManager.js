const mysql = require("mysql2");
require("dotenv").config();

const conn = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
});

const get_room = (roomID) => {
  const sql = "SELECT * FROM rooms WHERE id = ? LIMIT 1";
  return new Promise((resolve, reject) => {
    try {
      conn.connect((err) => {
        if (err) return reject(err);
        conn.query(sql, [roomID], (err, result) => {
          if (err) return reject(err);
          if (result) return resolve(result[0]);
        });
      });
    } catch (err) {
      return reject(err);
    }
  });
};

module.exports = { get_room };
