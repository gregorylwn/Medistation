const addAva = document.getElementById("addAva");
const cancelPsyModal = document.getElementById("cancelPsyModal");
const psyBody = document.getElementById("psyBody");

var psyModalOpen = false;

const togglePsyModal = () => {
  const psyModal = document.getElementById("psyModal");
  if (psyModalOpen) {
    psyModal.classList.remove("flex");
    psyModal.classList.add("hidden");
    psyBody.classList.toggle("overflow-hidden");
    psyModalOpen = false;
  } else {
    psyModal.classList.remove("hidden");
    psyModal.classList.add("flex");
    psyBody.classList.toggle("overflow-hidden");
    psyModalOpen = true;
  }
};

addAva.onclick = togglePsyModal;
cancelPsyModal.onclick = togglePsyModal;

const params = new URLSearchParams(window.location.search);
const selected = params.get("status");

const avaFilter = document.getElementById("avaFilter");
const avaFilterValue = document.getElementById("avaFilterValue");

avaFilterValue.value = selected;

if (!selected) {
  avaFilterValue.value = "Booked";
}

function filterAva() {
  avaFilter.submit();
}

avaFilterValue.onchange = filterAva;
