To run tailwindcss use the following command: npx tailwindcss -i style/input.css -o style/style.css --watch

To initialize project go into the js directory and run the command: npm install, then npm start

At no time edit bundle.js this will cause the video conference to break.

browserify conference.js -o bundle.js
